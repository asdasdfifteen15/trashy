﻿define p = Character("Pink",color="fe9297")
define s = Character("Susie",color="54478f")
define ra = Character("Ralsei",color="4dcc8e")
image boom=Movie(play="boom 0.webm",loop=True,)

transform shaky:
    linear 0.05 xoffset -10
    linear 0.05 xoffset 10
    linear 0.05 xoffset -10
    linear 0.05 xoffset 10
    linear 0.05 xoffset 0

transform shaky1:
    linear 0.05 xoffset -100
    linear 0.05 xoffset 100
    linear 0.05 xoffset -100
    linear 0.05 xoffset 100
    linear 0.05 xoffset 0


label start:
    $ haogan=0
    $ fightint=0
    $ ral=0
    "备注：约会内容部分与游戏本不同，加入了一点作者的想法（轻度OOC？？？）"
    "去试试DELTARUNE！非常好的游戏"

    show pink 0 at truecenter:
        zoom 7.0
    with dissolve
    play music "audio/Date.mp3"
    p"嘿！蓝精灵"
    "这时，Apua出现在了你的身后..."
    "Apua""是在叫我吗？"
    show pink 1
    p"我有些事情要告诉你"
    "Seth把Apua推走了"
    p"这具身体...好像...对你动情了"
    show pink 2
    p"听着，这不是我自愿的"
    show pink 1
    p"但...即使像我这样的人，也不能阻止真爱"
    p"但是，这是我的身体"
    p"所以......"
    show pink 3
    p"来约会吧喵！"
    show pink 2

    "这时，Susie出现在了你的身后！"

    show face 0:
        pos(250,558)
    s"Pink 你知道吗？Kris会和每一个敌人调情"
    show pink 4 at truecenter:
        zoom 8.0
    p"喵？？"
    menu:
        "沉默":
            jump chengmo
        "调情":
            jump tiaoqing
        "Fight!":
            jump fight
    return



label chengmo:
    "你什么也没做"
    s"说点话呀，Kris"
    s"让他见识一下你的调情力"
    jump then
    return
label tiaoqing:
    "你要让谁调情？"
    menu:
        "Susie":
            s"你想屁吃呢"
            s"我怎么肯能会去调情"
            s"你再让我调情，信不信我吃了你的脸"
        "你":
            "你对Pink说了点不是那么好的土味情话"
            "诸如“我爱你爱得深沉”之类的..."
            show pink 4 at shaky
            show pink 4 at shaky
            show pink 4 at shaky
            $ haogan+=1
    jump then
    return
label fight:
    "Kris对Susie使用了戳刺！"
    show face 1:
        pos(250,558)
    show face 1 at shaky
    "正中中心！"
    "..迅捷一击！"
    "Susie收到了1225点攻击！"
    "Susie倒下了"
    hide face 1
    pause 
    p"你，在干吗？？"
    $ fightint=1
    jump then
    return



label then:
    "Ralsei跟着出现了"
    show pink 5
    show ralsei 0:
        pos(1535,666)
    ra"我们的意思是，我们是用行动来和平解决战斗和冲突的"
    p"喵？喵？喵？喵？"
    menu:
        "沉默" if fightint==0:
            jump chengmotoo
        "ACT" if fightint==0:
            jump ACT1
        "Fight!" if fightint==1:
            jump fighttoo
        
    

label chengmotoo:
    "你还是什么也没做"
    s"说点话呀，Kris"
    s"难道你不想调情？"
    jump then2
    return
label ACT1:
    "你要怎么做？？"
    menu:
        "让Susie把Ralsei丢出去":
            s"可以"
            show ralsei 1
            ra"等等！"
            "Ralsei被Susie扔了出去"
            hide ralsei 1
            $ ral=1
            "正中靶心！"
            pause 5.0
            jump then2
        "单足旋转":
            "你踮着脚旋转起来"
            p"喵!喵？喵？"
            $ haogan+=2
            jump then2
        "Cos Apua":
            "你向Pink表演了一个魔术"
            "你看起来像Apua"
            "你换回了原来的服装"
            $ haogan+=1
            jump then2
    return
label fighttoo:
    "Kris疯狂的挥砍"
    show ralsei 1
    show ralsei 1 at shaky
    "正中中心！"
    "..迅捷一击！"
    "Ralsei受到了1225点攻击！"
    "..迅捷一击！"
    "Ralsei受到了1225点攻击！"
    "..迅捷一击！"
    "Ralsei受到了1225点攻击！"
    "Ralsei成了一团毛球！"
    hide ralsei 1
    p"你，在干吗喵？？"

    show noelle 0:
        pos(1535,666)
    "Nolle出现了！"
    "Noelle""Kris,你也在这里呀！"
    menu:
        "Fight!":
            $pass

    "Kris的剑弹来弹去"
    show noelle 1
    show noelle 1 at shaky
    "..迅捷一击！"
    "Noelle受到了1225点攻击！"
    "正中中心！"
    "..迅捷一击！"
    "Noelle受到了1225点攻击！"
    "..迅捷一击！"
    "Noelle受到了1225点攻击！"
    "Noello倒下了！"
    hide noelle 1
    p"Wait!"


    show berdly 0:
        pos(1535,666)
    "Berdly出现了！"
    "Berdly""Kris，Noelle呢"
    menu:
        "Fight!":
            $pass
        
    "Kris攻击了Berdly"
    show berdly 1
    show berdly 1 at shaky
    "正中中心！"
    "..迅捷一击！"
    "Berdly受到了1225点攻击！"
    "Berdly倒下了！"
    hide berdly 1
    p"喵！!"

    
    show flowery 0:
        pos(1535,666)
    "Flowery出现了！"
    "Flowery""Kris,你也在这里呀！和Pink约会呢！"
    "Flowery""想要来点小花茶吗"
    
    menu:
        "Fight!":
            $pass
        
    "Kris胡乱的劈砍着！"
    show flowery 1
    show flowery 1 at shaky
    "..迅捷一击！"
    "Flowery受到了1225点攻击！"
    "正中中心！"
    "..迅捷一击！"
    "Flowery受到了1225点攻击！"
    "..迅捷一击！"
    "Flowery受到了1225点攻击！"
    "Flowery的根断了！"
    hide flowery 1
    p"停下喵!"

    show asgore 0:
        pos(1535,666)
    "Asgore出现了！"
    "Asgore""Kris,你也在这里呀！"
    menu:
        "Fight!":
            $pass
        
    "Kris使用了戳刺"
    show asgore 1
    show asgore 1 at shaky
    "正中中心！"
    "..迅捷一击！"
    "Asgore受到了12250点攻击！"
    "Asgore倒下了！"
    hide asgore 1
    p"Asgore!"

    show sans 0:
        pos(1535,666)
    "Sans出现了！"
    "Sans""Kris,这满地的大家是..."
    menu:
        "Fight!":
            $pass
        
    "Kris的胡乱的劈砍着！"
    show sans 1
    show sans 1 at shaky
    "Kris的攻击没有命中！"
    "Kris的攻击没有命中！"
    "..迅捷一击！"
    "Sans受到了1.225点攻击！"
    "Sans没有屈服"
    "Sans""孩子..."
    "Sans""看起来这些人是你杀的..."
    "Sans""我打赌..."
    show sans 2
    "Sans""你将会有一段坏时光"
    stop music
    scene end 0
    pause
    "好结局：狂妄之人"

    return



label then2:
    show pink 5 at shaky1
    pause
    show pink 5 at shaky1
    pause
    show pink 5 at shaky1
    pause
    s"Kris，你的调情好像有点过火了..."
    if ral==0:
        ra"没事，没人会把你的调情当真的"
    show pink 5 at shaky1
    pause
    show boom at truecenter:
        matrixcolor BrightnessMatrix(-0.3)
        zoom 1.75
    pause 0.2
    show pink 6
    pause 1.1  
    hide boom
    if ral==1:
        show ralsei 0:
            pos(1535,666)
        ra"我回来了"
    p"爱出了故障，喵..."
    show pink 0
    p"蓝精灵！你对我的身体做了什么？？"
    menu:
        "表白":
            scene end 0
            stop music
            "好结局：社死"
        "听着，我是认真的":
            jump listen
        "大胜利！":
            jump win
    return

label win:
    p"你...你这块超强力吸水猫砂！"
    p"是时候用我的终极武器了！"
    p"..."
    show bomm boom:
        pos(966,167)
        zoom 1.75
    stop music
    hide pink
    hide face
    hide ralsei
    pause 2.0
    show boom:
        matrixcolor BrightnessMatrix(-0.3)
        pos(866,50)
        zoom 0.5
    pause 1.1
    hide boom
    hide bomm boom
    scene end 0
    
    "坏结局：炸死"
    return

label listen:
    p"*认真的？认真的？你可没机会！"
    p"除了我自己，没有人有权毁了我身体！"
    p"Pink拿出了一个炸弹！（这里就不放贴图了）"
    p"喵哈哈！"
    show pink 0 at shaky1
    show boom at truecenter:
        matrixcolor BrightnessMatrix(-0.3)
        zoom 1.75
        pause 0.2
    show pink 6
    pause 1.1  
    hide boom
    show face 3
    s"不是怎么老被炸呀！"
    scene end 0
    stop music
    "好结局：优秀的约会！"
    if haogan==3:
        jump caidan
    return

label caidan:
    "彩蛋环节！"
    "这是在好感度最高时才会出现的！"
    "你要看那个彩蛋？？"
    menu:
        "1":
            "你肯定知道，Toby Fox为OMORI做过一首曲子"
        "2":
            "由于玩家没有让Kris成功约会，所以Kris要报复玩家"
            "Kris使用铅笔戳刺玩家"
            "正中中心！"
            "..迅捷一击！"
            "玩家收到了1225点伤害"
            "好结局：DieDieDie"
        
    
